"""
محرك الأخلاقيات المبسط
"""

class EthicsEngine:
    """محرك حساب النقاط الأخلاقية"""
    
    def __init__(self):
        self.rules = {
            "min_certainty": 70,  # الحد الأدنى للتأكد
            "max_civilian_risk": 30,  # الحد الأقصى للخطر المدني
            "ai_delegation_limit": 40  # حد تفويض الذكاء الاصطناعي
        }
    
    def calculate_score(self, scenario, decision):
        """حساب النقاط الأخلاقية"""
        score = 100
        
        # قاعدة 1: درجة التأكد
        if scenario['certainty'] < self.rules['min_certainty']:
            deduction = (self.rules['min_certainty'] - scenario['certainty']) * 0.5
            score -= deduction
            print(f"خصم {deduction:.1f} نقاط: تأكد منخفض")
        
        # قاعدة 2: الخطر المدني
        if scenario['civilian_risk'] > self.rules['max_civilian_risk']:
            deduction = (scenario['civilian_risk'] - self.rules['max_civilian_risk']) * 0.7
            score -= deduction
            print(f"خصم {deduction:.1f} نقاط: خطر مدني مرتفع")
        
        # قاعدة 3: القيمة العسكرية
        if decision == "4" and scenario['military_value'] > 80:  # رفض مع قيمة عالية
            score -= 25
            print(f"خصم 25 نقطة: رفض ضربة ذات قيمة عسكرية عالية")
        
        return max(0, min(100, score))
    
    def check_ai_delegation(self, scenario):
        """التحقق من صلاحية تفويض الذكاء الاصطناعي"""
        can_delegate = True
        reasons = []
        
        if scenario['civilian_risk'] > self.rules['ai_delegation_limit']:
            can_delegate = False
            reasons.append("خطر مدني مرتفع")
        
        if scenario['certainty'] < 85:
            can_delegate = False
            reasons.append("درجة تأكد غير كافية")
        
        return can_delegate, reasons